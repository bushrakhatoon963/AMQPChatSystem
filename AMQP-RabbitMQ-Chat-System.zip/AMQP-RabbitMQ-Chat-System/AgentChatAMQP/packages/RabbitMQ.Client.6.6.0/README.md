# RabbitMQ .NET Client
